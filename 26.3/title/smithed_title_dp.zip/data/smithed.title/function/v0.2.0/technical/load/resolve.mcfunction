schedule clear smithed.title:v0.2.0/technical/tick
execute if score #smithed.title.major load.status matches 0 if score #smithed.title.minor load.status matches 2 if score #smithed.title.patch load.status matches 0 run function smithed.title:v0.2.0/technical/load
