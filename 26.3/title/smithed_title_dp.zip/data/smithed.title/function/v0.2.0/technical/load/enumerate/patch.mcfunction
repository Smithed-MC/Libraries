execute if score #smithed.title.patch load.status matches ..0 unless score #smithed.title.patch load.status matches 0 run function smithed.title:v0.2.0/technical/load/enumerate/set_version
