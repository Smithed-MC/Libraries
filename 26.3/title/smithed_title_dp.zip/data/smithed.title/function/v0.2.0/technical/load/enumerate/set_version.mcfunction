scoreboard players set #smithed.title.major load.status 0
scoreboard players set #smithed.title.minor load.status 2
scoreboard players set #smithed.title.patch load.status 0
scoreboard players set #smithed.title.set load.status 1
