scoreboard players reset #smithed.title.set load.status
scoreboard players add #smithed.title.major load.status 0
scoreboard players add #smithed.title.minor load.status 0
scoreboard players add #smithed.title.patch load.status 0
function smithed.title:v0.2.0/technical/load/enumerate/major
