execute as @a at @s run function smithed.crafter:v0.12.0/entity/player/slow_tick

schedule function smithed.crafter:v0.12.0/technical/slow_tick 5 replace
