schedule clear smithed.prevent_aggression:v0.4.0/technical/tick
execute if score #smithed.prevent_aggression.major load.status matches 0 if score #smithed.prevent_aggression.minor load.status matches 4 if score #smithed.prevent_aggression.patch load.status matches 0 run function smithed.prevent_aggression:v0.4.0/technical/load
