team add smithed.prevent_aggression
team modify smithed.prevent_aggression friendlyFire false

schedule function smithed.prevent_aggression:v0.4.0/technical/10_tick 10 replace
