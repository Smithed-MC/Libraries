scoreboard players reset #smithed.prevent_aggression.set load.status
scoreboard players add #smithed.prevent_aggression.major load.status 0
scoreboard players add #smithed.prevent_aggression.minor load.status 0
scoreboard players add #smithed.prevent_aggression.patch load.status 0
function smithed.prevent_aggression:v0.4.0/technical/load/enumerate/major
