tag @s add smithed.interaction.sittable_display
ride @p[tag=smithed.interaction.player] dismount
ride @p[tag=smithed.interaction.player] mount @s
