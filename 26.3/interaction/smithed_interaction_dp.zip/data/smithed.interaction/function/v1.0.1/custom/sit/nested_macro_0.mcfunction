$execute positioned ~ ~$(height) ~ run function smithed.interaction:v1.0.1/custom/sit/at_height
