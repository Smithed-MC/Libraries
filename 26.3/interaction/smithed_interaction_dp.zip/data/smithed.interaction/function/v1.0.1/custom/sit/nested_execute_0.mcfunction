scoreboard players operation @s smithed.interaction.sittable_id = #temp smithed.interaction.sittable_id
tag @s add smithed.interaction.sittable_display
tag @s add smithed.interaction.sittable_display.follow
ride @p[tag=smithed.interaction.player] dismount
ride @p[tag=smithed.interaction.player] mount @s
