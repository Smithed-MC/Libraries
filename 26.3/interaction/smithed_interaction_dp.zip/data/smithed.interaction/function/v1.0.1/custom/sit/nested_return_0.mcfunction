tag @s add smithed.interaction.sittable_interaction.follow
execute unless score @s smithed.interaction.sittable_id matches -2147483648..2147483647 store result score @s smithed.interaction.sittable_id run scoreboard players add #next smithed.interaction.sittable_id 1
execute store result score #temp smithed.interaction.sittable_id run scoreboard players get @s smithed.interaction.sittable_id
execute unless entity @e[tag=smithed.interaction.sittable_display.follow,type=item_display,distance=..0.001,predicate=smithed.interaction:v1.0.1/custom/sit/has_temp_id] summon item_display run function smithed.interaction:v1.0.1/custom/sit/nested_execute_0
