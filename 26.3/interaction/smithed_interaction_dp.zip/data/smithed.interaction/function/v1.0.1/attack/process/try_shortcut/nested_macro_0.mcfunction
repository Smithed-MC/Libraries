scoreboard players set #success smithed.interaction.temp 1
$function #smithed.interaction:on_left_click/$(custom)
