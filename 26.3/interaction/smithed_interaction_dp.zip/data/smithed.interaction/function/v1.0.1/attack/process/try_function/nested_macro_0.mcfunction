scoreboard players set #success smithed.interaction.temp 1
$function $(function)
