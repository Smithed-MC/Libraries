scoreboard players set #success smithed.interaction.temp 1
$function #smithed.interaction:on_right_click/$(custom)
