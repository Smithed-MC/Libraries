scoreboard players set #success smithed.interaction.temp 0
function smithed.interaction:v1.0.0/attack/process/try_shortcut/nested_macro_0 with entity @s data.smithed_interaction.on_left_click
execute if score #success smithed.interaction.temp matches 0 run tellraw @p[tag=smithed.interaction.player] [{text:"",color:"red"},"Interaction's custom shortcut failed: ",{text:'"',color:"aqua"},{entity:"@s",nbt:"data.smithed_interaction.on_left_click.custom",interpret:true,color:"green"},{text:'"',color:"aqua"}," is not a valid shortcut. Cannot contain characters not valid in a function path!"]
