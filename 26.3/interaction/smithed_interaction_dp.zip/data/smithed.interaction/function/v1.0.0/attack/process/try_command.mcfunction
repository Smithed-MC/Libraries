scoreboard players set #success smithed.interaction.temp 0
function smithed.interaction:v1.0.0/attack/process/try_command/nested_macro_0 with entity @s data.smithed_interaction.on_left_click
execute if score #success smithed.interaction.temp matches 0 run tellraw @p[tag=smithed.interaction.player] [{text:"",color:"red"},"Interaction's command failed: ",{text:'"',color:"aqua"},{entity:"@s",nbt:"data.smithed_interaction.on_left_click.command",interpret:true,color:"green"},{text:'"',color:"aqua"}," is not a valid command!"]
