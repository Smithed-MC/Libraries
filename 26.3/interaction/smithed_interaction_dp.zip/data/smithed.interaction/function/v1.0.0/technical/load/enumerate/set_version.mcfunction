scoreboard players set #smithed.interaction.major load.status 1
scoreboard players set #smithed.interaction.minor load.status 0
scoreboard players set #smithed.interaction.patch load.status 0
scoreboard players set #smithed.interaction.set load.status 1
