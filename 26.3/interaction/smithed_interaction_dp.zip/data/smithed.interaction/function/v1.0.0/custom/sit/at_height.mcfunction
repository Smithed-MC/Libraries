kill @e[tag=smithed.interaction.sittable_display,distance=..0.01,type=item_display,predicate=!smithed.interaction:v1.0.0/custom/sit/has_passenger]
execute unless entity @e[tag=smithed.interaction.sittable_display,distance=..0.01,type=item_display] summon item_display run function smithed.interaction:v1.0.0/custom/sit/at_height/nested_execute_0
