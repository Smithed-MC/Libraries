schedule function smithed.interaction:v1.0.0/custom/sit/tick 1
execute as @e[tag=smithed.interaction.sittable_display.follow,type=item_display] at @s run function smithed.interaction:v1.0.0/custom/sit/tick/nested_execute_0
