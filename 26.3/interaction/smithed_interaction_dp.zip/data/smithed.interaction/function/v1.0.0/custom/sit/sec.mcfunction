schedule function smithed.interaction:v1.0.0/custom/sit/sec 20
kill @e[tag=smithed.interaction.sittable_display,type=item_display,predicate=!smithed.interaction:v1.0.0/custom/sit/has_passenger]
