$execute positioned ~ ~$(height) ~ run function smithed.interaction:v1.0.0/custom/sit/at_height
