# core
scoreboard objectives add smithed.interaction.temp dummy
# custom : sit
scoreboard objectives add smithed.interaction.sittable_id dummy
scoreboard players add #next smithed.interaction.sittable_id 0
schedule function smithed.interaction:v1.1.0/custom/sit/sec 1
schedule function smithed.interaction:v1.1.0/custom/sit/tick 1
