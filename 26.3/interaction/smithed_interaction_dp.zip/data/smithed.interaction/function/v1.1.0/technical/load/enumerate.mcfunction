scoreboard players reset #smithed.interaction.set load.status
scoreboard players add #smithed.interaction.major load.status 0
scoreboard players add #smithed.interaction.minor load.status 0
scoreboard players add #smithed.interaction.patch load.status 0
function smithed.interaction:v1.1.0/technical/load/enumerate/major
