schedule clear smithed.interaction:v1.1.0/custom/sit/sec
schedule clear smithed.interaction:v1.1.0/custom/sit/tick
execute if score #smithed.interaction.major load.status matches 1 if score #smithed.interaction.minor load.status matches 1 if score #smithed.interaction.patch load.status matches 0 run function smithed.interaction:v1.1.0/technical/load
