# @public
execute if data entity @s data.smithed_interaction.on_right_click{height:"follow"} run return run function smithed.interaction:v1.1.0/custom/sit/nested_return_0
execute store result storage smithed.interaction:temp sitting.height double 0.5 run data get entity @s height
data modify storage smithed.interaction:temp sitting.height set from entity @s data.smithed_interaction.on_right_click.height
function smithed.interaction:v1.1.0/custom/sit/nested_macro_0 with storage smithed.interaction:temp sitting
