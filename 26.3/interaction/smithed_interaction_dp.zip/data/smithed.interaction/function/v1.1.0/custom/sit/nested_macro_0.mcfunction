$execute positioned ~ ~$(height) ~ run function smithed.interaction:v1.1.0/custom/sit/at_height
