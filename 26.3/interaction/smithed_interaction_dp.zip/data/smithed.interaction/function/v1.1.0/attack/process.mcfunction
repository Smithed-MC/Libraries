execute store result score #check_gametime smithed.interaction.temp run data get entity @s attack.timestamp
execute unless score #check_gametime smithed.interaction.temp = #current_gametime smithed.interaction.temp run return run data remove entity @s attack
execute on attacker unless entity @s[tag=smithed.interaction.player] run return fail
execute if data entity @s data.smithed_interaction.on_left_click.custom at @s run function smithed.interaction:v1.1.0/attack/process/try_shortcut
execute if data entity @s data.smithed_interaction.on_left_click.function at @s run function smithed.interaction:v1.1.0/attack/process/try_function
execute if data entity @s data.smithed_interaction.on_left_click.command at @s run function smithed.interaction:v1.1.0/attack/process/try_command
data remove entity @s attack
