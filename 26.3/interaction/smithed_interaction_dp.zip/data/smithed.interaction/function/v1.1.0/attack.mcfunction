advancement revoke @s only smithed.interaction:v1.1.0/attack
execute store result score #current_gametime smithed.interaction.temp run time query gametime
tag @s add smithed.interaction.player
execute as @e[tag=smithed.interaction,type=interaction,distance=..16] if data entity @s attack run function smithed.interaction:v1.1.0/attack/process
tag @s remove smithed.interaction.player
