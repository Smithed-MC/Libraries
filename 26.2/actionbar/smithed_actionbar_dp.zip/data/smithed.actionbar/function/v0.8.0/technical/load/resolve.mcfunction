schedule clear smithed.actionbar:v0.8.0/technical/tick
execute if score #smithed.actionbar.major load.status matches 0 if score #smithed.actionbar.minor load.status matches 8 if score #smithed.actionbar.patch load.status matches 0 run function smithed.actionbar:v0.8.0/technical/load
